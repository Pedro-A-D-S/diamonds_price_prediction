"""diamond-price-prediction
"""

__version__ = "0.1"
